知识点1

```html
<style>
    *{给所有标签都设置css样式}
</style>
```

如：（把所有标签的字体都设置成宋体）

```html
<style>
    *{ font-family:宋体}
</style>
```

---

知识点2

常用字体样式：

* font-family:字体 【设置标签字体】
* font-size: 值 【设置字体大小，单位px/em】
* color: 值【设置字体颜色，0xFFFFFF（16进制颜色），rgb（255,255,255）RGB颜色】
* font-style:italic;【字体样式斜体】
* font-style:normal;【字体样式正常】
* font-weight:bold【字体加粗】