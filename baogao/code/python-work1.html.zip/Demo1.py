while(1):
    a=''
    a = input()
    if(a=="苹果是水果吗"):
        print("是")
    elif(a=="猪肉是水果吗"):
        print("不是")