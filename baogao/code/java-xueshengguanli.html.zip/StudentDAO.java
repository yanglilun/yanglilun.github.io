package com.garen.wangpan3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;

public class StudentDAO {
	private String basepath = System.getProperty("user.dir");
	
//	��ȡ���ݿ�����
	public Connection getConn() throws SQLException {
		Connection cn;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/login";
			String user = "root";
			String password = "a14978435";
			cn = DriverManager.getConnection(url, user, password);
			return cn;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	
//	��ȡ����ѧ��
	public ArrayList<Student> getAllStudent() throws SQLException {
		String sql = "select * from student";
		Connection conn = this.getConn();
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		
		ArrayList<Student> list = new ArrayList<>();
		while(rs.next()){
			Student s = new Student();
			s.setSname(rs.getString("sname"));
			s.setSid(rs.getInt("sid"));
			s.setSage(rs.getInt("sage"));
			s.setSsex(rs.getString("ssex"));
			s.setPassword(rs.getString("password"));
			s.setSnum(rs.getString("snum"));
			s.setClassroom(rs.getString("classroom"));
			list.add(s);
		}
		rs.close();
		ps.close();
		conn.close();
		return list;
	}
	
//	����������ȡ
	public Student getStudentBySnum(String Snum) throws SQLException {
		String sql = "select * from student where snum = ?";
		Connection conn = this.getConn();
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, Snum);
		ResultSet rs = ps.executeQuery();
		
		if(!rs.next()){
			return null;
		}
		
		Student s = new Student();
		s.setSname(rs.getString("sname"));
		s.setSid(rs.getInt("sid"));
		s.setSage(rs.getInt("sage"));
		s.setSsex(rs.getString("ssex"));
		s.setPassword(rs.getString("password"));
		s.setSnum(rs.getString("snum"));
		s.setClassroom(rs.getString("classroom"));
		
		rs.close();
		ps.close();
		conn.close();
		
		return s;
	}

//	����ѧ��
	public boolean insertStudent(Student s){
		String sql = "insert into student values(null,?,?,?,?,?,?)";
		boolean f = false;
		try {
			Connection conn = this.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getClassroom());
			ps.setInt(3, s.getSage());
			ps.setString(4, s.getSsex());
			ps.setString(5, s.getPassword());
			ps.setString(6, s.getSnum());
			f = ps.executeUpdate() > 0;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;
	}
	
//	��������ɾ��ѧ��
	public boolean deleteStudentBySid(int sid){
		String sql = "delete from student where sid = ?";
		boolean flag = false;
		try {
			Connection conn = this.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, sid);
			
			flag = ps.executeUpdate()>0;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return flag;
	}
	
//	����ѧ��ɾ��ѧ��
	public boolean deleteStudentBySnum(String snum){
		String sql = "delete from student where snum = ?";
		boolean flag = false;
		try {
			Connection conn = this.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, snum);
			
			flag = ps.executeUpdate()>0;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	
//	����ѧ���޸�ѧ��
	public boolean updateSnameBySnum(String snum,String sname){
		String sql = "update student set sname = ? where snum = ?";
		boolean flag = false;
		try {
			Connection conn = this.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, sname);
			ps.setString(2, snum);
			
			flag = ps.executeUpdate()>0;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return flag;
	}
	
//	������ת���ַ���
	public String InputStreamToString(String path){
		String end="";
		String temp;
		String fpath = basepath + "/" + path;
		try {
			FileInputStream fis = new FileInputStream(fpath);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			
			
			while((temp = br.readLine()) != null){
				end += temp + "\n"; 
			}
			br.close();
			isr.close();
			fis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return end;
	}
	
//	�ַ���д���ļ�
	public void SaveStringToFile(String str,String path) {
		String fpath = basepath + "/" + path;
		try {
			System.out.println(fpath);
			File file = new File(fpath);
			if(!file.exists()){
				file.createNewFile();
			}
			FileOutputStream fos = new FileOutputStream(file);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			BufferedWriter br = new BufferedWriter(osw);
			br.write(str);
			br.flush();
			br.close();
			osw.close();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
//	���ļ���ȡ����ѧ��
	public List<Student> getAllStudentFromFile() {
		String streamToString = this.InputStreamToString("list.txt");
		List<Student> list = JSON.parseArray(streamToString, Student.class);
		return list;
	}
	
//	����ѧ�����ļ�
	public void saveStudentsToFile(List<Student> list,String path) {
		this.SaveStringToFile(JSON.toJSONString(list), path);
	}
	
//	׷��ѧ��
	public void insertStudentToFile(Student stu) {
		List<Student> list = this.getAllStudentFromFile();
		list.add(stu);
		this.saveStudentsToFile(list, "list.txt");
	}
	
//	����ѧ���޸�ѧ�����ļ���
	public void updateStudentByFile(String snum,String sname) {
		List<Student> list = this.getAllStudentFromFile();
		for(Student s : list){
			if(s.getSnum().equals(snum)){
				s.setSname(sname);
			}
		}
		this.saveStudentsToFile(list, "list.txt");
	}
	
//	����ѧ��ɾ��ѧ�����ļ���
	public void deleteStudentByFile(String snum) {
		List<Student> allStudentFromFile = this.getAllStudentFromFile();
		int temp = -1;
		for(int i =0;i<allStudentFromFile.size();i++){
			if(allStudentFromFile.get(i).getSnum().equals(snum)){
				temp = i;
			}
		}
		if(temp != -1){
			allStudentFromFile.remove(temp);
		}
		this.saveStudentsToFile(allStudentFromFile, "list.txt");
	}
	
	public static void main(String[] args) {
		new StudentDAO().insertStudentToFile(new Student());
	}
	
}
