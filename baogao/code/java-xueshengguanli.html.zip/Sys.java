package com.garen.wangpan3;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class Sys extends Frame implements ActionListener{
	
	Label biaoti = new Label("ѧ��¼��ϵͳ");
	
	Label sid_label = new Label("ѧ��");
	Label sname_label = new Label("����");
	TextField sid_text = new TextField();
	TextField sname_text = new TextField();
	Button addStu = new Button("����ѧ��");
	
	Button chaxun = new Button("��ѯ");
	TextArea chaxun_box = new TextArea();
	Button updateStu = new Button("�޸�ѧ��");
	
	Label shanchu_label = new Label("ѧ��");
	TextField shanchu_text = new TextField();
	Button shanchu_btn = new Button("ɾ��");
	
	public Sys(String title) {
		super(title);
		this.setSize(400, 400);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.CloseListening();
		this.setResizable(false);
		this.Init();
		this.setVisible(true);	
	}
	
	private void addCp(Component component){
		this.add(component);
		component.setVisible(true);
	}
	
	private void Init() {
		biaoti.setBounds(140, 30, 120, 20);
		sid_label.setBounds(20, 50, 40, 20);
		sname_label.setBounds(210, 50, 40, 20);
		sid_text.setBounds(70, 50, 120, 20);
		sname_text.setBounds(260, 50, 120, 20);
		addStu.setBounds(40, 80, 120, 20);
		addStu.addActionListener(this);
		updateStu.setBounds(200, 80, 120, 20);
		updateStu.addActionListener(this);
		
		chaxun.setBounds(20, 120, 40, 160);
		chaxun.addActionListener(this);
		chaxun_box.setBounds(80, 120, 300, 160);
		
		shanchu_label.setBounds(20, 300, 40, 20);
		shanchu_text.setBounds(80, 300, 160, 20);
		shanchu_btn.setBounds(280, 300, 60, 20);
		shanchu_btn.addActionListener(this);
		
		
		
		Component[] components = {
				biaoti,
				sid_label,
				sname_label,
				sid_text,
				sname_text,
				addStu,
				chaxun,
				chaxun_box,
				updateStu,
				shanchu_label,
				shanchu_btn,
				shanchu_text
		};
		
		for(Component c : components){
			this.addCp(c);
		}
	}
	
	private void CloseListening() {
		this.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent arg0) {
		        System.exit(0);
		    }
		});
	}
	
	private void displayStudentList(){
		ArrayList<Student> list = new ArrayList<>();
		list = (ArrayList<Student>) new StudentDAO().getAllStudentFromFile();
		String str = "ѧ��\t����\n";
		for(Student s : list){
			str+=s.getSnum()+"\t"+s.getSname()+"\n";
		}
		this.chaxun_box.setText(str);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object target = e.getSource();
		if(target == addStu){
			System.out.println("����ѧ��");
			String sid = this.sid_text.getText();
			String sname = this.sname_text.getText();
			Student stu = new Student();
			stu.setSnum(sid);
			stu.setSname(sname);
			System.out.println(stu);
			new StudentDAO().insertStudentToFile(stu);
			this.displayStudentList();
		}else if(target == chaxun){
			System.out.println("��ѯѧ��");
			this.displayStudentList();
		}
		else if(target == shanchu_btn){
		System.out.println("ɾ��ѧ��");
		String snum = this.shanchu_text.getText();
		System.out.println(snum);
		new StudentDAO().deleteStudentByFile(snum);
		this.displayStudentList();
	}
		else if(target == updateStu){
			System.out.println("�޸�ѧ��");
			String snum = this.sid_text.getText();
			String sname = this.sname_text.getText();
			new StudentDAO().updateStudentByFile(snum, sname);
			this.displayStudentList();
		}
	}
	
	public static void main(String[] args) {
		new Sys("ѧ��¼��ϵͳ");
	}
	
}
