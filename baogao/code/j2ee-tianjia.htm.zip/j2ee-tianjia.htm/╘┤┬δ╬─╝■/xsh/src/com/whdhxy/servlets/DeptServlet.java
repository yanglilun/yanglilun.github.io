package com.whdhxy.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.whdhxy.services.DeptService;

/**
 * Servlet implementation class DeptServlet
 */
@WebServlet({"/DeptServlet","/dept"})
public class DeptServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
   
	public void login(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		new DeptService().login(request, response);
	}

}
