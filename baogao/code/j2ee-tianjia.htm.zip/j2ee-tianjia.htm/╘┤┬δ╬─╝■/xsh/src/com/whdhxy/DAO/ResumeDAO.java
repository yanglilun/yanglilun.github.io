package com.whdhxy.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.whdhxy.entity.Resume;
import com.whdhxy.factory.DAOfactory;
import com.whdhxy.tool.DBUtils;

/**
 * ����DAO
 * @author garen
 */
public class ResumeDAO {
	
	private Connection conn;
	
	public ResumeDAO(Connection conn) {
		super();
		this.conn = conn;
	}

	/**��ȡ���м���*/
	public List<Resume> getAllResume() {
		String sql = "select * from resume";
		List<Resume> list = DBUtils.queryList(Resume.class,sql);
		return list;
	}
	
	/**���ݼ���id���Ҽ���*/
	public Resume getResumeByid(int id) {
		String sql = "select * from resume where id=?";
		Resume resume = DBUtils.queryOneObject(Resume.class, sql, id);
		return resume;
	}
	
	/**���ݲ�������ȡ����*/
	public List<Resume> getResumeByDeptname(String deptname) {
		String sql = "select * from resume where deptname=?";
		List<Resume> list = DBUtils.queryList(Resume.class, sql, deptname);
		return list;
	}
	
	/**���ݲ������Ͳ���������ȡ����*/
	public List<Resume> getResumeByDeptnameGroups(String deptname,String groups) {
		String sql = "select * from resume where deptname=? and groups=?";
		List<Resume> list = DBUtils.queryList(Resume.class, sql, deptname,groups);
		return list;
	}
	
	/**���Ӽ���*/
	public boolean insert(Resume r) {
		String sql = "insert into resume(name,sex,sid,pic,birthday,"
				+ "apptime,city,subject,grade,year,clevel,room,qq,idcard,"
				+ "tel,deptname,hobby,word,other,flag,groups) "
				+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection conn = DBUtils.getconn();
		int i = DBUtils.executeUpdate(conn, sql,r.getName(),r.getSex(),r.getSid(),
				r.getPic(),r.getBirthday(),r.getApptime(),r.getCity(),r.getSubject(),
				r.getGrade(),r.getYear(),r.getClevel(),r.getRoom(),r.getQq(),r.getIdcard(),
				r.getTel(),r.getDeptname(),r.getHobby(),r.getWord(),
				r.getOther(),r.getFlag(),r.getGroups());
		return i>0;
	}
	
	/**�޸ļ���״̬*/
	public boolean updateResumeFlag(int id,int flag) {
		String sql = "update resume set flag=? where id=?";
		int i = DBUtils.executeUpdate(conn, sql, flag,id);
		return i>0;
	}
	
	/**���ݼ���idɾ������*/
	public boolean delResumeById(int id) {
		String sql = "delete from resume where id=?";
		int i = DBUtils.executeUpdate(conn, sql, id);
		return i>0;
	}
	
}
