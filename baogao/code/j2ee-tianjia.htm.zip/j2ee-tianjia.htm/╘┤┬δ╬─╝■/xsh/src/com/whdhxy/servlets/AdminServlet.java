package com.whdhxy.servlets;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.whdhxy.entity.Dept;
import com.whdhxy.factory.DAOfactory;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/admin")
public class AdminServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;

//	public void login(HttpServletRequest request,HttpServletResponse response) {
//		String username = request.getParameter("username");
//		String password = request.getParameter("password");
//		Dept f = DAOfactory.newFactory().g(null).isexist(username, password);
//		
//		System.out.println(f);
//	}
}
