package com.whdhxy.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.whdhxy.entity.Resume;
import com.whdhxy.factory.DAOfactory;
import com.whdhxy.tool.DBUtils;
import com.whdhxy.tool.PropUtil;
import com.whdhxy.utils.GradeUtil;

/**
 * ����ҵ���
 * @author garen
 */

public class ResumeService {
	
	/**�������
	 * @throws IOException 
	 * @throws ServletException 
	 * @throws SQLException */
	public void insert(HttpServletRequest request,HttpServletResponse response) throws ParseException, IOException, ServletException, SQLException{
		response.setCharacterEncoding("utf-8");
		System.out.println("�յ��ύ");
		
//		�洢֤����
		Part part = request.getPart("pic");
		String pic = this.savePart(part);
		
		String sid = request.getParameter("sid");
		Resume r = new Resume();
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String birth = request.getParameter("birthday");
		String city = request.getParameter("city");
		String grade = request.getParameter("grade");
		String subject = request.getParameter("subject");
		String year = request.getParameter("year");
		String clevel = request.getParameter("clevel");
		String room = request.getParameter("room");
		String qq = request.getParameter("qq");
		String tel = request.getParameter("tel");
		String deptname = request.getParameter("deptname");
		String groups = request.getParameter("groups");
		String hobby = request.getParameter("hobby");
		String word = request.getParameter("word");
		System.out.println("ѧԺ"+grade);
		System.out.println("�꼶"+year);
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		
		if(birth.equals("")){
			System.out.println("birthΪ��");
			r.setBirthday(new Date());
		}else{
			r.setBirthday(fmt.parse(birth));
		}
		Date apptime = new Date();
		r.setSid(sid);
		r.setName(name);
		r.setSex(sex);
		r.setCity(city);
		r.setPic(pic);
		r.setGrade(new GradeUtil().getGradeById(grade));
		r.setSubject(subject);
		r.setYear(year);
		r.setApptime(apptime);
		r.setClevel(clevel);
		r.setRoom(room);
		r.setQq(qq);
		r.setTel(tel);
		r.setDeptname(deptname);
		r.setGroups(groups);
		r.setHobby(hobby);
		r.setWord(word);
		Connection conn = DBUtils.getconn();
		boolean f = DAOfactory.newFactory().getResumeDAO(conn).insert(r);
		conn.close();
		System.out.println(f);
		response.sendRedirect("success.html");
		
	}
	
	/**�洢part��Դ*/
	public String savePart(Part p) throws IOException {
		String fileName = p.getSubmittedFileName();
		

		Properties prop = PropUtil.getProp();
		String path = prop.getProperty("base");
		
		path +=File.separator+fileName;
		System.out.println(path);
		InputStream is = p.getInputStream();
		FileOutputStream fos = new FileOutputStream(path);
		byte[] b = new byte[1024];
		int len=0;
		while((len=is.read(b))>0){
			fos.write(b, 0, len);
		}
		fos.close();
		is.close();
		File f = new File(path);
		path = f.getName();
		return path;
	}
	
	/**��ʾ��������
	 * @throws IOException */
	public void showinfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
//		��ȡ����id
		String id = request.getParameter("id");
		System.out.println(id);
//		��ȡ����
		Resume r = DAOfactory.newFactory().getResumeDAO(null).getResumeByid(Integer.parseInt(id));
//		�浽session��
		HttpSession session = request.getSession();
		session.setAttribute("resume", r);
		PrintWriter pw = response.getWriter();
		pw.write("info.jsp");
		pw.flush();
		pw.close();
	}
}
