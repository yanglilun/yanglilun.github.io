#include<stdio.h>
int jiecheng(int n);
int main()
{	
	int sum=0,m=1;
	while(1)
	{
		sum+=jiecheng(m);
		if(sum<100){
			m++;
		}else{
			printf("%d",m);
			break;
		}
	}
	return 0;
}
int jiecheng(int n)
{
	int end=1;
	for(int i=1;i<=n;i++)
	{
		end*=i;
	}
	return end;
}
