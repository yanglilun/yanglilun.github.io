#include<stdio.h>
#include<math.h>
int IsSquare(int n);
int main()
{
	int a,b,c,d;
	for(int i=1000;i<=9999;i++){
		a=i/1000;
		b=i/100%10;
		c=i/10%10;
		d=i%10;
		if(a==b&&c==d&&IsSquare(i)){
			printf("����������:%d\n",i);
		}
	}
	return 0;
}
int IsSquare(int n){
	if(sqrt(n)==(int)sqrt(n))
	return 1;
	else
	return 0;
}
