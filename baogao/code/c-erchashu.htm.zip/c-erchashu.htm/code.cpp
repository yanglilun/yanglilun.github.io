#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>

using namespace std;

typedef struct node
{
	char data;
	struct node *lchild;
	struct node *rchild;
}BTNode;
char pre[100];
char in[100];
void CreateBTree(BTNode * &b,char *str)
{
	BTNode * St[1000],*p;
	int top=-1,k,j=0;
	char ch;
	b=NULL;
	ch=str[j];
	while(ch!='\0')
	{
          switch(ch)
          {
          	case '(':top++;St[top]=p;k=1;break;
          	case ')':top--;break;
          	case ',':k=2;break;
          	default:p=(BTNode *)malloc(sizeof(BTNode));
          	p->data=ch;
          	p->lchild=p->rchild=NULL;
          	if(b==NULL)
          	b=p;
          	else
          	{
          		switch(k)
          		{
          			case 1:St[top]->lchild=p;break;
          			case 2:St[top]->rchild=p;break;
          		}
          	}
          }
		j++;
		ch=str[j];
	}
}
void DispBTree(BTNode *b)
{
	if(b!=NULL)
	{
		printf("%c",b->data);
		if(b->lchild!=NULL || b->rchild!=NULL)
		{
			printf("(");
			DispBTree(b->lchild);
			if(b->rchild!=NULL)
				printf(",");
			DispBTree(b->rchild);
			printf(")");
		}
	}
}
void DestroyBTree(BTNode * &b)
{
	if(b!=NULL)
	{
		DestroyBTree(b->lchild);
		DestroyBTree(b->rchild);
		free(b);
	}
}
int BTHeight(BTNode *b)
{
	int lchildh,rchildh;
	if(b==NULL)
	return 0;
	else
	{
		lchildh=BTHeight(b->lchild);
		rchildh=BTHeight(b->rchild);
		return(lchildh>rchildh) ? lchildh+1 : rchildh+1;
	}
}
void DispLeaf(BTNode *b)
{
	if(b!=NULL)
	{
		if(b->lchild==NULL && b->rchild==NULL)
		printf("%c",b->data);
		DispLeaf(b->lchild);
		DispLeaf(b->rchild);
	}
}
void DispSingle(BTNode *b)
{
	if(b!=NULL)
	{
		if((b->lchild!=NULL && b->rchild==NULL)|| (b->lchild==NULL && b->rchild!=NULL))
		printf("%c",b->data);
		DispSingle(b->lchild);
		DispSingle(b->rchild);
	}
}
int FindLevel(BTNode *b,char x,int h)
{
	int l;
	if(b==NULL)
		return 0;
	else if(b->data==x)
		return h;
	else
	{
		l=FindLevel(b->lchild,x,h+1);
		if(l!=0)
			return l;
		else
			return FindLevel(b->rchild,x,h+1);
	}
}
void PreOrder(BTNode *b)
{
	int i=0;
	if(b!=NULL)
	{
		pre[i++]=b->data;
		printf("%c",b->data);
		PreOrder(b->lchild);
		PreOrder(b->rchild);
	}
}
void InOrder(BTNode *b)
{
	int i=0;
	if(b!=NULL)
	{
		InOrder(b->lchild);
		in[i++]=b->data;
		printf("%c",b->data);
		InOrder(b->rchild);
	}
}
void PostOrder(BTNode *b)
{
	if(b!=NULL)
	{
		PostOrder(b->lchild);
		PostOrder(b->rchild);
		printf("%c",b->data);
		
	}
}
BTNode *CreateBT1(char *pre,char *in,int n)
{
	BTNode *b;
	char *p;
	int k;
	if(n<=0)
	return NULL;
	b=(BTNode *)malloc(sizeof(BTNode));
	b->data=*pre;
	for(p=in;p<in+n;p++)
	if(*p==*pre)
	break;
	k=p-in;
	b->lchild=CreateBT1(pre+1,in,k);
	b->rchild=CreateBT1(pre+k+1,p+1,n-1-k);
	return b;
}
int main()
{
	BTNode *b;
	char s[20];
	char x;
	printf("���ű�ʾ��");
	gets(s);
	CreateBTree(b,s);
	printf("�߶�Ϊ:");
	printf("%d\n",BTHeight(b));
	printf("Ҷ�ӽ��:");
	DispLeaf(b);
	printf("\n");
	printf("��֧���:");
	DispSingle(b);
	printf("\n");
	x=getchar();
	printf("%d\n",FindLevel(b,x,1));
	printf("������������");
	PreOrder(b);
	printf("\n");
	printf("������������");
	InOrder(b);
	printf("\n");
	printf("������������");
	PostOrder(b);
	printf("\n");
	CreateBT1(pre,in,strlen(pre));
	DispBTree(b);
	DestroyBTree(b);
	return 0;
}
