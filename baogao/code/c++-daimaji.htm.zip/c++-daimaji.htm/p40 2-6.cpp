#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int a = 7, b = 18, c = 9, x, y;
	x = (b >= c && b <= a);

	cout << "x=" << x << endl;
	x = (a || b + c && b - c);

	cout << "x=" << x << endl;
	x = !(a > b && !c || 'a');

	cout << "x=" << x << endl;
	x = (!(a + b) + c - 1 && b + c/2);

	cout << "x=" << x << endl;
	!(x = a) && (y = b) && '\0';

	cout << "x=" << x <<"\ty"<<y<<endl;
	'\0' || (y = b) || (x = 8);

	cout << "x=" << x << "\ty" << y << endl;
	getchar();
	return 0;
}