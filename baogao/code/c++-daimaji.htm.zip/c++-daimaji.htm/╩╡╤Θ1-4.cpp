#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	float a;
	cin >> a;
	cout << (a - 32) * 5 / 9;
	getchar();
	return 0;
}