#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int a = 5, b = 10;
	cout << "(a > 4 ? a + 7 : b - 5)=" << (a > 4 ? a + 7 : b - 5) << endl;
	cout << "(a < 4 ? a + 7 : b - 5)=" << (a < 4 ? a + 7 : b - 5) << endl;
	cout << "(a + b > 16 ? a + 7 : b - 5 ? a + 10 : b + 6)" << (a + b > 16 ? a + 7 : b - 5 ? a + 10 : b + 6) << endl;
	
	
	getchar();
	return 0;
}