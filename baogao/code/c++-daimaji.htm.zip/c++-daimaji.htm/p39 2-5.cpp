#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int i = 3;
	cout << -i++ << "  ";
	cout << i << endl;
	cout << i++ + 3 <<"  ";

	cout << i << endl;
	cout << i++ + i << "   ";

	cout << i << endl;

	getchar();
	return 0;
}