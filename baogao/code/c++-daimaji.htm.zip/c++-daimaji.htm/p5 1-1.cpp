#include <iostream>
using namespace std;
void main()
{
	int perimeter,area;
	int length=20,width=10;
	perimeter=2*(length+width);
	area=length*width;
	cout<<"perimeter="<<perimeter<<endl;
	cout<<endl;
	cout<<"area="<<area<<endl;
}
