#include<iostream>
#include<string>
using namespace std;
int main()
{	
	string greeting = "hello world!";
	cout << "hello world";
	cout << "welcome to C++" << endl;
	cout << greeting << endl;

	return 0;
}