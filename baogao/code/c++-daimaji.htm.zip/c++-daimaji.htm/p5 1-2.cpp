#include <iostream>
using namespace std;
class Rectangle
	{public:
		
		Rectangle(float w=0,float l=0){width=w;length=1;}
		
		void GetArea(){cout<<"area="<<width*length<<endl;}
		void GetPerim(){cout<<"perimeter="<<2*(width+length)<<endl;}
		private:
			float width,length;
};
	void main()
		{
			Rectangle a(10,20);
			
		
		
			a.GetPerim();
			a.GetArea();
	}