#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int a[2];
	cout << "�����볤��"<<endl;
	for (int i = 0;i < 2;i++)
	{
		cin >> a[i];
	}
	cout << "���" << a[0] * a[1];
	getchar();
	getchar();
	return 0;
}