#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int n,temp[4], m;
	cin >> n;
	temp[0] = n / 1000;
	temp[1] = n / 100 % 10;
	temp[2] = n / 10 % 10;
	temp[3] = n % 10;
	m = temp[3] * 1000 + temp[2] * 100 + temp[1] * 10 + temp[0];
	cout <<m;
	
	getchar();
	getchar();
	return 0;
}