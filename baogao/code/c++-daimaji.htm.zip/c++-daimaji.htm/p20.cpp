#include<iostream>
using namespace std;
int main()
{
	cout << "My" << "Sister";
	cout << "is" << "a ";
	cout << "beautleful firl!" << endl;
	return 0;
}