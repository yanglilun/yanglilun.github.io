#include<iostream>
using namespace std;
int main()
{
	cout << "Wellcome to C++ World\n";
	cout << "My Friend!" << endl;
	return 0;
}