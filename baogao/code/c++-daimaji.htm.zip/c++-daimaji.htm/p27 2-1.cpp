#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int a, c, d, b = 322;
	float x, z, y = 4.56;
	char ch1 = 'd', ch2;
	a = y;
	x = b;
	c = ch1;
	ch2 = b;
	z = y + b;
	d = b + ch1;
	cout << "a=" << a << "\tx=" << x << endl;
	cout << "c=" << c << "\tch2=" << ch2 << endl;
	cout << "z=" << z << "\td=" << d << endl;
	getchar();
	return 0;
}