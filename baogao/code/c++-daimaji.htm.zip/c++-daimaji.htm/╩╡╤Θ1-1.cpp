#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	cout << "***************" << endl;
	cout << "Hello!"<<endl;
	cout << "***************" << endl;
	getchar();
	return 0;
}