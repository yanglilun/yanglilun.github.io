#include<stdio.h>
char* jm(char text[]); 
int main()
{
char text[]="Hello World";
printf("ԭ��:%s\n",text);
printf("����:%s\n",jm(text)); 
printf("����:%s\n",jm(text));
return 0;
}
char* jm(char text[])
{
	int i;
	for(i=0;text[i]!='\0';i++)
	{
		if('A'<=text[i]&&text[i]<='Z')
		{
			text[i]='Z'-text[i]+'A';	
		}else if('a'<=text[i]&&text[i]<='z')
		{
			text[i]='z'-text[i]+'a';	
		}
	}
	return text;
}

