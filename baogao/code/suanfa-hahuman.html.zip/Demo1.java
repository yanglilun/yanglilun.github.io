package FCJAVA;

import java.util.Arrays;

public class Demo1 {
	
	public static void main(String[] args) {
		int arr[] = {1,6,5,4,3,2};
		Demo1.mergeSort(arr);
		for(int i:arr){
			System.out.print(i);
		}
	}

	 private static void mergeSort(int[] original) {
	        if (original == null) {
	        	System.out.println("������");
	        }
	        int length = original.length;
	        if (length > 1) {
	            int middle = length / 2;
	            int partitionA[] = Arrays.copyOfRange(original, 0, middle);//
	            int partitionB[] = Arrays.copyOfRange(original, middle, length);
	            // �ݹ����
	            mergeSort(partitionA);
	            mergeSort(partitionB);
	            sort(partitionA, partitionB, original);
	        }
	    }

	    private static void sort(int[] partitionA, int[] partitionB, int[] original) {
	        int i = 0;
	        int j = 0;
	        int k = 0;
	        while (i < partitionA.length && j < partitionB.length) {
	            if (partitionA[i] <= partitionB[j]) {
	                original[k] = partitionA[i];
	                i++;
	            } else {
	                original[k] = partitionB[j];
	                j++;
	            }
	            k++;
	        }
	        if (i == partitionA.length) {
	            while (k < original.length) {
	                original[k] = partitionB[j];
	                k++;
	                j++;
	            }
	        } else if (j == partitionB.length) {
	            while (k < original.length) {
	                original[k] = partitionA[i];
	                k++;
	                i++;
	            }
	        }
	    }
}
