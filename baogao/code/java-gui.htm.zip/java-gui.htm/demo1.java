package demo1;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.*;
import java.io.File;

import javax.swing.JOptionPane;




public class demo1 extends Frame implements ActionListener,KeyListener,FocusListener{
TextField name=new TextField(10);
Checkbox man=new Checkbox("��"),woman=new Checkbox("Ů");
CheckboxGroup sex=new CheckboxGroup();
Checkbox like1=new Checkbox("����");
Checkbox like2=new Checkbox("����");
Checkbox like3=new Checkbox("����");
Choice jiguan=new Choice();
Button bt= new Button("ȷ��");
Label l1=new Label("����"),l2=new Label("�Ա�");
Label l3=new Label("����"),l4=new Label("����");
TextArea wenben=new TextArea();
static int i=1;
public demo1(String title){
	super(title);
	this.setSize(400,400);
	this.setLayout(null);
	//����
	l1.setBounds(20,40,40,20);
	name.setBounds(60, 40, 100, 20);
	//�ձ�
	l2.setBounds(20, 70, 40, 20);
	man.setCheckboxGroup(sex);
	woman.setCheckboxGroup(sex);
	man.setBounds(80, 70, 40, 20);
	woman.setBounds(120, 70, 40, 20);
	sex.setSelectedCheckbox(man);
	//����
	l3.setBounds(20, 100, 40, 20);
	like1.setBounds(80, 100, 60, 20);
	like2.setBounds(140, 100, 60, 20);
	like3.setBounds(200, 100, 100, 20);
	//����
	l4.setBounds(20, 130, 40, 20);
	jiguan.add("����");
	jiguan.add("�Ϻ�");
	jiguan.add("���");
	jiguan.add("����");
	jiguan.add("��̨");
	jiguan.add("Ϋ��");
	jiguan.setBounds(80, 130, 60, 20);
	bt.setBounds(170, 160, 60, 20);
	//������
	wenben.setBounds(10, 200,this.getWidth(),180);
	
	this.add(l1);
	this.add(l2);
	this.add(l3);
	this.add(l4);
	this.add(name);
	this.add(man);
	this.add(woman);
	this.add(like1);
	this.add(like2);
	this.add(like3);
	this.add(jiguan);
	this.add(bt);
	this.add(wenben);
	//exit
	this.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
			System.exit(0);
		}
	});
	setLocationRelativeTo(null);

	//����bt
	bt.addActionListener(this);
	name.addFocusListener(this);
}
 
public static void main(String args[]) {
	demo1 app=new demo1("��Ϣ¼��");
	app.setVisible(true);
}

@Override
public void focusGained(FocusEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void focusLost(FocusEvent arg0) {
	//������������
	if(name.getText().length()==0||name.getText()==null){
		JOptionPane.showMessageDialog(null, "������ ����!","ERROR",JOptionPane.ERROR_MESSAGE);
	}
	//������ȷ��������
	else if(!name.getText().matches("^[\u4e00-\u9fa5]{2,4}$")){
		JOptionPane.showMessageDialog(null, "����ȷ��������!","ERROR",JOptionPane.ERROR_MESSAGE);
	}
}

@Override
public void keyPressed(KeyEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void keyReleased(KeyEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void keyTyped(KeyEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void actionPerformed(ActionEvent e) {
	//��ʾ
	Object ob=e.getSource();
	if(ob==bt){
		
		String s="��";
		s+=s+i+"��ͬѧ\n"+"����:"+name.getText()+"\t�Ա�:"+sex.getSelectedCheckbox().getLabel();
		s+="\t����: "+(!like1.getState()&&!like2.getState()&&!like3.getState()?"δ��д":"")+(like1.getState()?like1.getLabel():"")+" "+(like2.getState()?like2.getLabel():"")+" "+(like3.getState()?like3.getLabel():"");
		s+="\t����: "+jiguan.getSelectedItem()+"\n";
		wenben.append(s);
		i++;
	}
	
}

} 