package com.whdhxy.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class YzmServlet
 */
@WebServlet("/yzm")
public class YzmServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
   
	public void check(HttpServletRequest request,HttpServletResponse response) throws IOException {
		System.out.println("У����֤��");
//		��ȡ��֤�����֤��
		String yzm = request.getParameter("yzm");
		String code = (String) request.getSession().getAttribute("code");
		PrintWriter pw = response.getWriter();
//		�ж��Ƿ���ͬ
		if(yzm.equals(code)){
			pw.write("true");
			pw.flush();
		}else{
			pw.write("false");
			pw.flush();
		}
		pw.close();
	}

}
