package com.whdhxy.factory;

import java.sql.Connection;

import com.whdhxy.DAO.DeptDAO;
import com.whdhxy.DAO.ResumeDAO;

/**
 * DAO����
 * @author garen
 *
 */
public class DAOfactory {

	private static DAOfactory factory = new DAOfactory();
	
	public static DAOfactory newFactory() {
		return factory;
	}
	
	public DeptDAO getDeptDAO(Connection conn) {
		return new DeptDAO(conn);
	}
	
	public ResumeDAO getResumeDAO(Connection conn) {
		return new ResumeDAO(conn);
	}
}
