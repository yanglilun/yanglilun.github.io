package com.whdhxy.DAO;

import java.sql.Connection;
import java.util.List;
import java.util.Objects;

import com.whdhxy.entity.Admin;
import com.whdhxy.tool.DBUtils;

public class AdminDAO {

	Connection conn;

	public AdminDAO(Connection conn) {
		super();
		this.conn = conn;
	}
	
	/**��ȡ���й���Ա*/
	public List<Admin> getAllAdmin() {
		String sql = "select * from admin";
		List<Admin> allAdmin = DBUtils.queryList(Admin.class, sql);
		return allAdmin;
		
	}
	
	/**�жϹ���Ա�Ƿ����*/
	public boolean isexist(String username,String password) {
		String sql = "select * from admin where username=?"
				+ "and password=?";
		Admin admin = DBUtils.queryOneObject(Admin.class, sql, username,password);
		return Objects.nonNull(admin)?true:false;
	}
}
