package com.whdhxy.DAO;

import java.sql.Connection;
import java.util.List;
import java.util.Objects;

import com.whdhxy.entity.Admin;
import com.whdhxy.entity.Dept;
import com.whdhxy.entity.Resume;
import com.whdhxy.factory.DAOfactory;
import com.whdhxy.tool.DBUtils;

/**
 * ���Ź���
 * @author garen
 *
 */
public class DeptDAO {
	
	Connection conn;

	public DeptDAO(Connection conn) {
		super();
		this.conn = conn;
	}
	
	/**��ȡ���в����û�*/
	public List<Dept> getAllDept() {
		String sql = "select * from dept";
		List<Dept> list = DBUtils.queryList(Dept.class, sql);
		return list;
	}
	
	/**�����û�����*/
	public boolean insert(Dept d) {
		String sql = "insert into dept(username,password,deptname,group,level) "
				+ "values(?,?,?,?,?)";
		int i = DBUtils.executeUpdate(conn, sql, d.getUsername(),d.getPassword(),
				d.getDeptname(),d.getGroups(),d.getLevel());
		return i>0;
	}
	
	/**�жϲ����û��Ƿ����*/
	public Dept isexist(String username,String password) {
		String sql = "select * from dept where username=?"
				+ "and password=?";
		Dept dept = DBUtils.queryOneObject(Dept.class, sql,username,password);
		return dept;
	}
	
	/**����idɾ�������û�*/
	public boolean delDeptById(int id) {
		String sql = "delete from dept where id=?";
		int i = DBUtils.executeUpdate(conn, sql, id);
		return i>0;
	}
	
}
