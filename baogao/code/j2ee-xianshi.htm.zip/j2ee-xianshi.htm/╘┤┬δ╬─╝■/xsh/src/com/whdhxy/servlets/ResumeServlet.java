package com.whdhxy.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.whdhxy.services.ResumeService;

/**
 * Servlet implementation class ResumeServlet
 */
@WebServlet("/resume.do")
@MultipartConfig
public class ResumeServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	
	/**�ύ����
	 * @throws IOException 
	 * @throws ServletException 
	 * @throws SQLException */
	public void send(HttpServletRequest request,HttpServletResponse response) throws ParseException, IOException, ServletException, SQLException{
		new ResumeService().insert(request, response);
	}
	
	/**������֯*/
	public void join(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		System.out.println("join����");
		String deptname = request.getParameter("deptname");
		System.out.println(deptname);
		HttpSession session = request.getSession();
		session.setAttribute("deptname", deptname);
		response.sendRedirect("resume.jsp");
	}
	
	/**��ʾ��������*/
	public void showinfo(HttpServletRequest request,HttpServletResponse response) {
		try {
			new ResumeService().showinfo(request, response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
