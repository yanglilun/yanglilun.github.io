package com.whdhxy.services;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.whdhxy.entity.Dept;
import com.whdhxy.entity.Resume;
import com.whdhxy.factory.DAOfactory;

public class DeptService {
	
	public void login(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Dept dept = DAOfactory.newFactory().getDeptDAO(null).isexist(username, password);
		System.out.println(dept);
		if(Objects.isNull(dept)){
			System.out.println("������");
			response.sendRedirect("dept.html");
		}else{
			System.out.println("��½�ɹ�");
//			��¼�ɹ�
//			��ȡ����֯���м���
			String deptname = dept.getDeptname();
			List<Resume> list = DAOfactory.newFactory().getResumeDAO(null).getResumeByDeptname(deptname);
			System.out.println(list);
//			����session
			HttpSession session = request.getSession();
			session.setAttribute("dept", dept);
//			����request
			request.setAttribute("list", list);
			request.getRequestDispatcher("deptmenu.jsp").forward(request, response);
		}
	}
	
}
