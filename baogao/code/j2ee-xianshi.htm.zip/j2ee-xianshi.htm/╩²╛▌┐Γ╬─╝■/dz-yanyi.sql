/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50550
 Source Host           : 127.0.0.1:3306
 Source Schema         : dz-yanyi

 Target Server Type    : MySQL
 Target Server Version : 50550
 File Encoding         : 65001

 Date: 23/09/2019 17:55:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(255) CHARACTER SET gbk COLLATE gbk_chinese_ci NULL DEFAULT NULL,
  `ssex` varchar(255) CHARACTER SET gbk COLLATE gbk_chinese_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1014 CHARACTER SET = gbk COLLATE = gbk_chinese_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1002, '学生2', '男');
INSERT INTO `student` VALUES (1001, '学生1', '男');
INSERT INTO `student` VALUES (1003, '学生3', '男');
INSERT INTO `student` VALUES (1004, '学生4', '男');
INSERT INTO `student` VALUES (1005, '学生5', '男');
INSERT INTO `student` VALUES (1006, '学生6', '男');
INSERT INTO `student` VALUES (1007, '学生7', '男');
INSERT INTO `student` VALUES (1008, '学生8', '男');
INSERT INTO `student` VALUES (1009, '学生9', '男');
INSERT INTO `student` VALUES (1010, '学生10', '男');
INSERT INTO `student` VALUES (1011, '学生11', '男');

SET FOREIGN_KEY_CHECKS = 1;
