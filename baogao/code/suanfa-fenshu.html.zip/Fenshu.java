package com.garen;

import java.util.Objects;

/**
 * @Author yang_li
 * @Date 2020/12/16 14:39
 */
public class Fenshu {
//    ����
    private int fenzi;
//    ��ĸ
    private int fenmu;

    public Fenshu() {
    }

    public Fenshu(int fenzi, int fenmu) {
        this.fenzi = fenzi;
        this.fenmu = fenmu;
    }

    public int getFenzi() {
        return fenzi;
    }

    public void setFenzi(int fenzi) {
        this.fenzi = fenzi;
    }

    public int getFenmu() {
        return fenmu;
    }

    public void setFenmu(int fenmu) {
        this.fenmu = fenmu;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Fenshu fenshu = (Fenshu) o;
        return fenzi == fenshu.fenzi &&
                fenmu == fenshu.fenmu;
    }

//    �����ӷ�
    public Fenshu sum(Fenshu fenshu){
//        �����жϷ�ĸ�Ƿ���ͬ
        if(this.fenmu == fenshu.fenmu){
//            �����ͬ����ֱ�ӷ������
            this.fenzi += fenshu.fenzi;
            return this;
        }else {
//            �������ͬ�������ĸ����С������
            int gongbeishu = this.gongbeishu(this.fenmu, fenshu.fenmu);
//            �ı��Լ�,����
            int beishu1 = gongbeishu / this.fenmu;
            this.fenzi *= beishu1;
//            �ı���ӵķ���,����
            int beishu2 = gongbeishu / fenshu.fenmu;
            fenshu.fenzi *= beishu2;
//            �����
            return new Fenshu(this.fenzi+fenshu.fenzi, gongbeishu);
        }
    }


    @Override
    public int hashCode() {
        return Objects.hash(fenzi, fenmu);
    }

    @Override
    public String toString() {
        return fenzi+"/"+fenmu;
    }

//    ����С������
    private int gongbeishu(int a,int b){
        int gongbeishu = a*b;

//        �ж�a��b�ĸ���
        int max = a,min=b;
        if(b>a){
            max = b;
            min = a;
        }
        for(int i=min;i<=gongbeishu;i++){
//            �жϵ�ǰi�Ƿ��ǹ�����
            if(i%a == 0 && i%b == 0){
                gongbeishu = i;
                break;
            }
        }
        return gongbeishu;
    }


    public static void main(String[] args) {
        Fenshu fenshu = new Fenshu(1, 4);
        Fenshu fenshu2 = new Fenshu(2, 6);
        System.out.println(fenshu.sum(fenshu2));


    }
}

