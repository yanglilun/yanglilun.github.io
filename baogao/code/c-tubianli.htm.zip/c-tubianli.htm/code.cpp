#include<Stdio.h>
#include<graphics.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>

#define N 8
#define MAX N*N
#define TRUE 1
#define FALSE 0
#define LEN (300/N)

typedef struct{
	short int row;
	short int col;
	short int dir;
}element;
element stack[MAX];
typedef struct{
	short int vert;
	short int horiz;
}offsets;
offsets move[8];

int maze[N+2][N+2];












int mark[N+2][N+2];
int exit_row=N,exit_col=N;



void add(int *top,element item)
{
	if(*top>=MAX-1)
	{
		printf("the stack is full!\n");
		return;
	}
	stack[++*top]=item;
}


element deletee(int *top)
{
	if(*top==-1)
	{
		printf("the stack is empty\n");
		exit(1);
	}
	return stack[(*top)--];
}


void path(void)
{
	int i,j,k,row,col,next_row,next_col,dir,found=FALSE;
	int gd=VGA;
	int gm=VGAHI;
	element position;
	int top=0;
	mark[1][1]=1;
	stack[0].row=1;
	stack[0].col=1;
	stack[0].dir=1;
	move[0].vert=-1;move[0].horiz=0;
	move[1].vert=-1;move[1].horiz=1;
	move[2].vert=0;move[2].horiz=1;
	move[3].vert=1;move[3].horiz=1;
	move[4].vert=1;move[4].horiz=0;
	move[5].vert=1;move[5].horiz=-1;
	move[6].vert=0;move[6].horiz=-1;
	move[7].vert=-1;move[7].horiz=-1;
	
	initgraph(&gd,&gm,"");
	while(top>-1&&!found){
		position=deletee(&top);
		row=position.row;
		col=position.col;
		dir=position.dir;
		
		while(dir<8&&!found){
			next_row=row+move[dir].vert;
			next_col=col+move[dir].horiz;
			
			if(next_row==exit_row&&next_col==exit_col)
			   found=TRUE;
			else if(!maze[next_row][next_col]&&!mark[next_row][next_col])
			{
				mark[next_row][next_col]=1;
				position.row=row;
				position.col=col;
				position.dir=++dir;
				add(&top,position);
				row=next_row;
				col=next_col;
				dir=0;
			}
			else ++dir;
		}
	}
	for(j=1;j<=N;j++)
	   for(k=1;k<=N;k++)
	   {
	   	 setcolor(WHITE);
	   	 circle(j*LEN,k*LEN,10);
	   	 setcolor(YELLOW);
	   	 outtextxy(j*LEN-2,k*LEN-2,maze[k][j]?"1":"0");
	   }
	   if(found)
	   {
	   	outtextxy(20,10,"The path is:");
	   	setcolor(RED);
	   	for(i=0;i<top;i++)
	   	{
	   	line(stack[i].col*LEN,stack[i].row*LEN,stack[i+1].col*LEN,stack[i+1].row*LEN);
		}
		line(stack[i].col*LEN,stack[i].row*LEN,col*LEN,row*LEN);
		line(col*LEN,row*LEN,exit_col*LEN,exit_row*LEN);
	   }
	   else outtextxy(20,10,"The maze does not have a path");
}

int main()
{
	int i,j;
	char c;
	srand((unsigned)time(0));
	system("cls");
	for(i=0;i<N+2;i++){
		maze[0][i]=1;
		maze[i][0]=0;
		maze[N+1][i]=1;
		maze[i][N+1]=1;
	}
	printf("yes or no");
	c=getchar();
if(c=='y'||c=='Y')
	{
		for(i=1;i<N;i++)
			for(j=1;j<N;j++)
			{
				scanf("%d",&maze[i][j]);
			}
	}else
	{
		printf("finish\n");
		for(i=1;i<N;i++)
			for(j=1;j<N;j++)
			{
				maze[i][j]=rand()%2;
			}
			maze[N][N]=0;
			maze[1][1]=0;
			for(i=1;i<N;i++)
			{
				for(j=1;j<N;j++)
					printf("%3d",maze[i][j]);
					printf("\n");
			}
	}
	path();
	getch();
	return 0;
}