package com.garen.baogao.work1;

public class Auto {

    public double speed;



    public void start(){
        System.out.println("汽车启动了！");
    }

    public void speedUp(){
        System.out.println("汽车加速！");
    }
    public void stop(){
        System.out.println("汽车停车！");
    }

}
