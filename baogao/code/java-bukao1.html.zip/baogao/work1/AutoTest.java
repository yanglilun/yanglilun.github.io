package com.garen.baogao.work1;


public class AutoTest {

    public static void main(String[] args) {
//        创建一个0人的公交车
        Bus bus = new Bus(0);
//        公交发车
        bus.start();
//        公交停车
        bus.stop();
//        公交上两个乘客
        bus.goton();
        bus.goton();
//        公交下一个乘客
        bus.gotoff();
    }
}
