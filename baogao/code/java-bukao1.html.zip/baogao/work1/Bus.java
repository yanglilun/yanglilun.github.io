package com.garen.baogao.work1;


public class Bus extends Auto{
    public int passeger;

    public Bus(int passeger) {
        this.passeger = passeger;
    }

    public void goton(){
        this.passeger++;
        System.out.println("乘客上车！，现在乘客数量:"+this.passeger);
    }

    public void gotoff(){
        this.passeger--;
        System.out.println("乘客下车！，现在乘客数量:"+this.passeger);
    }
}
