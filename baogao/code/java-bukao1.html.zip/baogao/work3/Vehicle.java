package com.garen.baogao.work3;

public interface Vehicle {

    public void start();

    public void speedUp();

    public void stop();
}
