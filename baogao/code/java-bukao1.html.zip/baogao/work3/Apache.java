package com.garen.baogao.work3;

public class Apache extends ToyPlane {

    @Override
    public void start() {
        System.out.println("阿帕奇玩具启动！");
    }

    @Override
    public void speedUp() {
        System.out.println("阿帕奇玩具加速！");
    }

    @Override
    public void stop() {
        System.out.println("阿帕奇玩具停车！");
    }
}
