package com.garen.baogao.work3;

public class ToyPlane implements Vehicle {
    @Override
    public void start() {

    }

    @Override
    public void speedUp() {

    }

    @Override
    public void stop() {

    }
}
