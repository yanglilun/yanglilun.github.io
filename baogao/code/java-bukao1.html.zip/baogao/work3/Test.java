package com.garen.baogao.work3;

public class Test {
    public static void main(String[] args) {
        Apache apache = new Apache();
        apache.start();
        apache.speedUp();
        apache.stop();

    }
}
