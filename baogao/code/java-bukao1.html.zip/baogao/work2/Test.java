package com.garen.baogao.work2;

public class Test {
    public static void main(String[] args) {
        Triangle triangle = new Triangle(2, 3, 8, 4);
        triangle.perimeter();
        triangle.area();
    }
}
