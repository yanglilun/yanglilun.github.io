package com.garen.baogao.work2;

public abstract class Shape {

//    求周长
    public void perimeter(){

    }
//    求面积
    public void area(){

    }
}
