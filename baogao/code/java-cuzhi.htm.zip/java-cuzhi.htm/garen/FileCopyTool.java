package com.garen;

import java.awt.Label;
import java.io.*;

/**
 * @Author yang_li
 * @Date 2020/5/24 12:30
 */

public class FileCopyTool implements Runnable{
    public String filepath;
    public String copypath;
    public Label baifen;

    public FileCopyTool(Label baifen) {
    	this.baifen=baifen;
	}

	private void Copy() throws IOException {
        FileInputStream fis = new FileInputStream(filepath);
        FileOutputStream fos = new FileOutputStream(copypath);

        byte temp[]=new byte[1024];
        int len;
        while((len=fis.read(temp))>0){
            fos.write(temp,0,len);
        }
        fos.close();
        fis.close();
        System.out.println("done");
        return;
    }

    @Override
    public void run() {
        Thread shouhu = new Thread(new Runnable() {
            @Override
            public void run() {
                File file = new File(filepath);
                double length = file.length()*1.0;
                File copy = new File(copypath);
                System.out.println(copy.exists());
                while(true){
                    double bfb = copy.length() / length;
                    System.out.println(String.format("%.0f",bfb*100));
                    baifen.setText("��ǰ����:"+String.format("%.0f",bfb*100)+"%");
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(bfb>=1){
                    	System.out.println("100�� !!");
                    	return;
                    }
                }
                
                
            }
        });
        shouhu.setDaemon(true);
        shouhu.start();

        try {
            Copy();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        FileCopyTool fileCopyTool = new FileCopyTool(null);
        fileCopyTool.filepath="E:\\#ceshi\\demo1.mp4";
        fileCopyTool.copypath="E:\\#ceshi\\demo\\demo1.mp4";
        Thread t = new Thread(fileCopyTool);
        t.start();
    }
}
