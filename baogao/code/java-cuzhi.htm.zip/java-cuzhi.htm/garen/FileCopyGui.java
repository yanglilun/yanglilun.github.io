package com.garen;

import java.awt.Button;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * @Author yang_li
 * @Date 2020/5/24 13:35
 */

public class FileCopyGui extends JFrame implements ActionListener{
    Button bt1 = new Button("ѡ��Ҫ�����ļ�");
    Button bt2 = new Button("ѡ��Ŀ���ļ���");
    Button bt3 = new Button("��ʼ����");
    TextField filepath = new TextField("");
    TextField copypath = new TextField("");
    Label baifen = new Label("��ǰ����:0%");
    Label banquan = new Label("����By:����ѧԺ");
    Label banquan2 = new Label("�������ѧѧԺ");
    
    public FileCopyGui(){
    	bt1.setBounds(40, 20, 100, 20);
    	bt2.setBounds(40, 60, 100, 20);
    	filepath.setBounds(40, 40, 200, 20);
    	copypath.setBounds(40, 80, 200, 20);
    	bt3.setBounds(40, 100, 100, 20);
    	baifen.setBounds(40, 140, 200, 40);
    	baifen.setFont(new Font(null, 0, 20));
    	banquan.setBounds(20, 200, 300, 40);
    	banquan.setFont(new Font(null, WIDTH, 30));
    	banquan2.setBounds(20, 220, 300, 100);
    	banquan2.setFont(new Font(null, WIDTH, 30));    	
        this.add(filepath);
        this.add(copypath);
        this.add(bt1);
        this.add(bt2);
        this.add(bt3);
        this.add(baifen);
        this.add(banquan);
        this.add(banquan2);

        this.setSize(400,400);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        this.bt1.addActionListener(this);
        this.bt2.addActionListener(this);
        this.bt3.addActionListener(this);
        
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
        
    }

    public static void main(String[] args) {
        new FileCopyGui();
    }


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1){
			JFileChooser chooser = new JFileChooser();
	        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	        chooser.showDialog(new JLabel(), "ѡ��");
	        File file = chooser.getSelectedFile();
	        if(file==null){
	        	return;
	        }
	        filepath.setText(file.getAbsoluteFile().toString());
		}
		
		if(e.getSource()==bt2){
			JFileChooser chooser = new JFileChooser();
	        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	        chooser.showDialog(new JLabel(), "ѡ��");
	        File file = chooser.getSelectedFile();
	        if(file==null){
	        	return;
	        }
	        copypath.setText(file.getAbsoluteFile().toString());
		}
		
		
		if(e.getSource()==bt3){
			String filepath = this.filepath.getText().replace("/", "//");
			String fname = new File(filepath).getName();
			String copypath = this.copypath.getText().replace("/", "//")+"//"+fname;
			System.out.println(filepath);
			System.out.println(copypath);
			FileCopyTool fileCopyTool = new FileCopyTool(baifen);
			fileCopyTool.filepath=filepath;
			fileCopyTool.copypath=copypath;
			Thread t = new Thread(fileCopyTool);
			t.start();
			
		}
	}
}
