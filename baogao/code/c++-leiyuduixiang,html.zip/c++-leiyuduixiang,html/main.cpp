#include <iostream>
using namespace std;

class Vehicle {
public:
	double MaxSpeed;
	double Weight;

	void Run();
	void Stop();

	Vehicle(double MaxSpeed, double Weight) {
		this->MaxSpeed = MaxSpeed;
		this->Weight = Weight;
		cout << "Vehicle的构造函数\n";
	}

};

class Bicycle : Vehicle {
public:
	double height;

	Bicycle(double MaxSpeed, double Weigh, double height) :Vehicle(MaxSpeed, Weight) {
		this->height = MaxSpeed;
		cout << "Bicycle的构造函数\n";
	}

	~Bicycle() {
		cout << "Bicycle的销毁函数\n";
	}

	void Run() {
		cout << "Bicycle启动\n";
	};
	void Stop() {
		cout << "Bicycle停止\n";
	};
};

class Motorcar : Vehicle {
public:
	int seatNum;

	Motorcar(double MaxSpeed, double Weigh, double seatNum) :Vehicle(MaxSpeed, Weight) {
		this->seatNum = MaxSpeed;
		cout << "Motorcar的构造函数\n";
	}

	~Motorcar() {
		cout << "Motorcar的销毁函数\n";
	}

	void Run() {
		cout << "Motorcar启动\n";
	};
	void Stop() {
		cout << "Motorcar停止\n";
	};
};

class Motorcycle : Bicycle {
public:
	Motorcycle(double MaxSpeed, double Weight, double height) :Bicycle(MaxSpeed, Weight, height) {
	}

	~Motorcycle() {
		cout << "Motorcycle的销毁函数\n";
	}


	void Run() {
		cout << "Motorcycle启动\n";
	};
	void Stop() {
		cout << "Motorcycle停止\n";
	};
};


int main() {
	Bicycle b = Bicycle(20, 50, 80);
	b.Run();
	b.Stop();
}