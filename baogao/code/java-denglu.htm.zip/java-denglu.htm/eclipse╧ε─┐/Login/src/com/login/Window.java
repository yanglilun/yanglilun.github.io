package com.login;

import java.awt.Button;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JOptionPane;
public class Window extends Frame implements ActionListener{
//	���ڿؼ�Ԫ��
	Label title = new Label("����ѧԺ - ��¼����");
	Label username_label = new Label("�û���");
	Label password_label = new Label("����");
	TextField username_field = new TextField();
	TextField password_field = new TextField();
	Button denglu = new Button("��¼");
	Button zhuce = new Button("ע��");
	
	public Window() {
		this.setSize(400, 400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setLayout(null);		
		
		this.add(title);
		this.add(username_label);
		this.add(username_field);
		this.add(password_label);
		this.add(password_field);
		this.add(denglu);
		this.add(zhuce);
		
//		���ÿؼ�����
		this.title.setBounds(110, 40, 200, 20);
		this.title.setFont(new Font(null,0,20));
		this.username_label.setBounds(180, 60, 80, 20);
		this.username_field.setBounds(100, 80, 200, 20);
		this.password_label.setBounds(180, 120, 80, 20);
		this.password_field.setBounds(100, 140, 200, 20);
		this.denglu.setBounds(120, 180, 160, 20);
		this.zhuce.setBounds(120, 210, 160, 20);
		
		
		//this����������dWindowListener
		this.addWindowListener(new WindowAdapter() {
		    //����һ��windowadapter����������дwindowCLosing����
		    @Override
		    public void windowClosing(WindowEvent arg0) {
		        //�����˳�
		        System.exit(0);
		    }
		});
		
//		��¼����¼�
		this.denglu.addActionListener(this);
		this.zhuce.addActionListener(this);
	}
	
	public static void main(String[] args) {
		Window window = new Window();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==denglu){
//			��ȡ�û�������
			String username = this.username_field.getText();
			String password = this.password_field.getText();
			if(username.equals("")||password.equals("")){
				JOptionPane.showMessageDialog(null, "��������������");
				return;
			}
			InputStream is = this.getClass().getClassLoader().getResourceAsStream("users.cfg");
			ArrayList<User> users = null;
			try {
				ObjectInputStream ois = new ObjectInputStream(is);
				users = (ArrayList<User>) ois.readObject();
				ois.close();
				is.close();
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			System.out.println(users);
//			�������е��û�
			for(User u : users){
				if(u.username.equals(username) && u.password.equals(password)){
					JOptionPane.showMessageDialog(null, "��½�ɹ�");
					return;
				}
			}
			JOptionPane.showMessageDialog(null, "�û�������");
		}
		
		if(e.getSource()==zhuce){
//			��ȡ�û�������
			String username = this.username_field.getText();
			String password = this.password_field.getText();
			InputStream is = this.getClass().getClassLoader().getResourceAsStream("users.cfg");
			ArrayList<User> users = null;
			try {
				ObjectInputStream ois = new ObjectInputStream(is);
				users = (ArrayList<User>) ois.readObject();
				ois.close();
				is.close();
			} catch (IOException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			System.out.println(users);
			for(User u : users){
				if(u.username.equals(username)){
					JOptionPane.showMessageDialog(null, "�û��Ѵ���!!");
					return;
				}
				
			}
			users.add(new User(username, password));
			
			String path = InitCfg.class.getClassLoader().getResource("users.cfg").getPath();
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path));
				oos.writeObject(users);
				oos.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "ע��ɹ�");
		}
		
	}
}
