#include<stdio.h>

int prime(int m);

int main(){
	int c = 1;
	for(int i=0;i<100;i++){
		if(prime(i)){
			printf("%d\t",i);
			c++;
			if(c%10 == 1){
				printf("\n");
			}
		}
		
	}
}

//�ж�����
int prime(int m){
	for(int i=2;i<m;i++)
		if(m%i==0&&i<m)	return 0;
	return 1;
}
