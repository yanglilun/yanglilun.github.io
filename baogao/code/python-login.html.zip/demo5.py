import json

class userDao:
    def getAllUser(self):
        f = open("users.txt","r")
        str = f.read()
        list = eval(str)
        f.close()
        return list

    def insertUser(self,user):
        list = self.getAllUser()
        list.append(user)
        jsonstr = json.dumps(list)
        f = open("users.txt","w+")
        f.write(jsonstr)
        f.close()

    def initData(self):
        f = open("users.txt", "w+")
        f.write("[]")
        f.close()

def login():
    print("请输入用户名:")
    username = input()
    print("请输入密码:")
    password = input()
    list = userDao().getAllUser()
    flag = True
    for u in list:
        if(u["username"]==username):
            flag=False
            if(u["password"]==password):
                print("登陆成功！")
            else:
                print("密码错误！")
    if(flag):
        print("用户不存在!")

def register():
    print("请输入用户名:")
    username = input()
    print("请输入密码:")
    password = input()
    list = userDao().getAllUser()
    flag = False
    for u in list:
        if(u["username"]==username):
            flag=True
            break
    if(flag):
        print("用户已经存在!")
    else:
        u={
            "username":username,
            "password":password
        }
        userDao().insertUser(u)
        print("注册成功！")

while(1):
    print("\n欢迎使用python登录系统")
    print("本系统使用IO&json制作")
    print("1.登录")
    print("2.注册")
    print("3.重置数据")
    print("0.退出")
    c = input()
    if(c=='0'):
        exit()
    elif(c=='1'):
        login()
    elif(c=='2'):
        register()
    elif(c=='3'):
        userDao().initData()
        print("重置成功！")
    else:
        print("")
