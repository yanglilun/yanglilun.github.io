#include<iostream>
#include<stdio.h>
#define PI 3.14
using namespace std;
class Circle {
protected:
	double radius;
	double C;
	double S;
public:
	//����
	void newCircle(double radius=0) {
		this->radius = radius;
		//����
		C = 2 * PI*radius;
		S = PI * radius*radius;
	}
	void disp_C() {
		cout << this->C << endl;
	}
	void disp_S() {
		cout << S << endl;
	}
};
int main()
{
	Circle circle;
	circle.newCircle(10);
	circle.disp_C();
	circle.disp_S();
	getchar();
	getchar();
	return 0;
}