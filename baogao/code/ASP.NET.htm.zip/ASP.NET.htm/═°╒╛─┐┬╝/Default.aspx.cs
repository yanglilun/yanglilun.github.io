﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;//oledb
using System.Data;//DataSet
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.head_label.Text = "数据库连接状态:" + "未连接" + "<br>";//显示状态
        //接单界面
        this.bt_id.Visible = false;
        this.input_id.Visible = false;
        this.input_jdy.Visible = false;
        this.home.Visible = false;
        this.input_sr_jdy.Visible = false;
        this.bt_search_jdy.Visible = false;

    }
    public OleDbConnection GetConnection()
    {
        //新版access连接字符串
        //string sPath = Server.MapPath("~\\Database1.accdb");
        //string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sPath + ";";

        //旧版access连接字符串
        string sPath = Server.MapPath("~\\维修.mdb");
        string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + sPath + ";";
        //创建连接对象
        OleDbConnection myConn = new OleDbConnection(connectionString);
        return myConn;
    }

    protected void choosebt_Click(object sender, EventArgs e)//点击接单以后
    {
        if(this.input_id.Value.Length==0||this.input_jdy.Value.Length==0)
        {
            Response.Write("<script>alert('请正确输入值')</script>");
            this.kejiedan.Visible = true;
            return;
        }
        this.kejiedan.Visible = true;
        string id = this.input_id.Value;
        string jdy = this.input_jdy.Value;
        string sqlstr = "update 维修表单 set 接单员='" + jdy+"' where id="+id;
        OleDbConnection myConn = GetConnection();
        myConn.Open();
        this.head_label.Text = "数据库连接状态:" + myConn.State + "<br>";//显示状态
        OleDbCommand myCmd = new OleDbCommand(sqlstr, myConn);
        OleDbDataAdapter myDa = new OleDbDataAdapter(myCmd);
        DataSet myDs = new DataSet();
        myDa.Fill(myDs);

        sqlstr = "select id,姓名,栋,号,QQ,手机,问题1,问题2,接单员 from 维修表单 where id=" + id;
        this.head_label.Text = "数据库连接状态:" + myConn.State + "<br>";//显示状态
        myCmd = new OleDbCommand(sqlstr, myConn);
        myDa = new OleDbDataAdapter(myCmd);
        myDs = new DataSet();
        myDa.Fill(myDs);
        if (myDs.Tables[0].Rows.Count > 0)
        {
            //this.gridview.AllowPaging = true;//启用分页
            //this.gridview.PageSize = 3;//每页三行
            //this.gridview.AutoGenerateColumns = true;//自动生成行
            this.gridview.DataSource = myDs;//设置数据源
            this.gridview.DataBind();//绑定数据
        }
        myConn.Close();
        Response.Write("<script>alert('接单成功！')</script>");
    }

    protected void kejiedan_Click(object sender, EventArgs e)//查看可接单
    {
        this.gridview.DataBind();
        this.bt_id.Visible = true;
        this.input_id.Visible = true;
        this.input_jdy.Visible = true;
        this.kejiedan.Visible = false;
        this.home.Visible = true;
        this.all.Visible = false;
        this.search_jdy.Visible = false;
        string sqlstr = "select id,姓名,栋,号,QQ,手机,问题1,问题2,接单员 from 维修表单 where 接单员 is null";
        OleDbConnection myConn = GetConnection();
        myConn.Open();
        this.head_label.Text = "数据库连接状态:" + myConn.State + "<br>";//显示状态
        OleDbCommand myCmd = new OleDbCommand(sqlstr, myConn);
        OleDbDataAdapter myDa = new OleDbDataAdapter(myCmd);
        DataSet myDs = new DataSet();
        myDa.Fill(myDs);
        if (myDs.Tables[0].Rows.Count > 0) 
        {
            //this.gridview.AllowPaging = true;//启用分页
            //this.gridview.PageSize = 3;//每页三行
            //this.gridview.AutoGenerateColumns = true;//自动生成行
            this.gridview.DataSource = myDs;//设置数据源
            this.gridview.DataBind();//绑定数据
        }
        if(myDs.Tables[0].Rows.Count==0)
        {
            Response.Write("<script>alert('暂无订单可接！')</script>");
        }
        
        myConn.Close();
    }

    protected void home_Click(object sender, EventArgs e)
    {
        this.input_id.Visible = false;
        this.input_jdy.Visible = false;
        this.bt_id.Visible = false;
        this.kejiedan.Visible = true;
        this.all.Visible = true;
        this.search_jdy.Visible = true;
    }

    protected void all_Click(object sender, EventArgs e)//查看所有订单
    {
        this.all.Visible = false;
        this.kejiedan.Visible = false;
        this.home.Visible = true;
        string sqlstr = "select id,姓名,栋,号,QQ,手机,问题1,问题2,接单员 from 维修表单 order by id desc";
        OleDbConnection myConn = GetConnection();
        myConn.Open();
        this.head_label.Text = "数据库连接状态:" + myConn.State + "<br>";//显示状态
        OleDbCommand myCmd = new OleDbCommand(sqlstr, myConn);
        OleDbDataAdapter myDa = new OleDbDataAdapter(myCmd);
        DataSet myDs = new DataSet();
        myDa.Fill(myDs);
        if (myDs.Tables[0].Rows.Count > 0)
        {
            //this.gridview.AllowPaging = true;//启用分页
            //this.gridview.PageSize = 3;//每页三行
            //this.gridview.AutoGenerateColumns = true;//自动生成行
            this.gridview.DataSource = myDs;//设置数据源
            this.gridview.DataBind();//绑定数据
        }
        myConn.Close();
    }

    protected void search_jdy_Click(object sender, EventArgs e)//查询界面
    {
        this.input_sr_jdy.Visible = true;
        this.bt_search_jdy.Visible = true;
        this.search_jdy.Visible = false;
        this.kejiedan.Visible = false;
        this.all.Visible = false;
        this.home.Visible = true;
        
    }

    protected void bt_search_jdy_Click(object sender, EventArgs e)//查询
    {
        this.home.Visible = true;
        string jdy = this.input_sr_jdy.Value;
        string sqlstr = "select id,姓名,栋,号,QQ,手机,问题1,问题2,接单员 from 维修表单 where 接单员='" + jdy+"'";
        OleDbConnection myConn = GetConnection();
        myConn.Open();
        this.head_label.Text = "数据库连接状态:" + myConn.State + "<br>";//显示状态
        OleDbCommand myCmd = new OleDbCommand(sqlstr, myConn);
        OleDbDataAdapter myDa = new OleDbDataAdapter(myCmd);
        DataSet myDs = new DataSet();
        myDa.Fill(myDs);
        if (myDs.Tables[0].Rows.Count > 0)
        {
            //this.gridview.AllowPaging = true;//启用分页
            //this.gridview.PageSize = 3;//每页三行
            //this.gridview.AutoGenerateColumns = true;//自动生成行
            this.gridview.DataSource = myDs;//设置数据源
            this.gridview.DataBind();//绑定数据
        }
        myConn.Close();
    }
}