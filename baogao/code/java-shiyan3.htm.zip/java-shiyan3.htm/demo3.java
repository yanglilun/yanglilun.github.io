package demo1;

public class demo3 {
	public static void main(String args[]) {
		vehicle v=new vehicle(8, 10.0);
		smallcar c=new smallcar(6);
		truck t=new truck(10);
		v.dismessage();
		c.dismessage();
		t.dism2();t.dism3();
	}
}

class vehicle{
	int wheels;
	double weights;
	vehicle(int wheels,double weights)
	{
		this.wheels=wheels;
		this.weights=weights;
	}
	void dismessage()
	{
		System.out.println("这个车车轮个数为："+wheels+"重量是"+weights+"斤");
	}
}

class smallcar extends vehicle
{
	int loader;
	smallcar(int loader) {
		super(8,10.0);
		this.loader=loader;
	}
	void dissmall()
	{
		System.out.println("这个小汽车可以载"+loader+"人");
	}
}
class truck extends smallcar
{
	int payload;
	truck(int payload) {
		super(6);
		this.payload=payload;
	}
	void dism2()
	{
		System.out.println("卡车的载重为"+payload+"kg");
	}
	void dism3(){
		System.out.println("这个卡车有"+wheels+"个轮子"+weights+"斤"+"可以载"+loader+"人"+"载重"+payload+"斤");
	}
}