package demo1;

public class demo2 {
	public static void main(String args[]) {
		bank b1 = new bank("admin","root","2018-12-01",10001,0.0);
		b1.cun(100000.00);
		b1.qu(100.00);
		b1.info();
	}
}
class bank{
	String user,name,time;
	int id;
	double money;
	bank(String user,String name,String time,int id,double money)
	{
		this.user=user;
		this.name=name;
		this.time=time;
		this.id=id;
		this.money=money;
	}
	public void cun(double inmoney)
	{
		money=money+inmoney;
		System.out.println("成功存款"+inmoney);
	}
	public void qu(double outmoney) {
		if(money-outmoney>=0)
		{
			money=money-outmoney;
			System.out.println("成功取款"+outmoney);
		}
	}
	public void info() {
		System.out.println("余额还有"+money);
	}
}