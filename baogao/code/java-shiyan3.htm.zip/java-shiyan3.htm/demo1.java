package demo1;

public class demo1 {
	public static void main(String[] args) {
		car c= new car("奔驰S600",50000);
		c.dismessage();
	}
}

class car{
	String chepai;
	float price,price1;
	car(String chepai,float price)
	{
		this.chepai=chepai;
		this.price1=price*4/5;
		this.price=price;
	}
	
	void dismessage()
	{
		System.out.println("这辆车的品牌是"+chepai+"\n原价:"+price+"\n打折后："+price1);
	}
}
