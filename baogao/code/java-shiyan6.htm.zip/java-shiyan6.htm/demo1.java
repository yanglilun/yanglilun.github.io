package demo1;

import javax.swing.JOptionPane;

class fufen	extends Exception{
	fufen(){
		System.out.println("����Ϊ����");
	}
}
class gaofen extends Exception{
	gaofen(){
		System.out.println("��������");
	}
}
public class demo1 {
	static final int number=2;
	int score[]=new int[number];
	
	public void check(int fenshu)throws fufen,gaofen {
		if(fenshu<0){
			throw new fufen();
		}else if(fenshu>100){
			throw new gaofen();
		}
	}
	
	public void luru() {
		int i;
		for(i=0;i<number;i++){
			try{
				score[i]=Integer.parseInt(JOptionPane.showInputDialog("�������"+(i+1)+"��ͬѧ�ĳɼ�"));
				
			}catch (NumberFormatException e) {
				
			}
			try{
				check(score[i]);
			}catch (gaofen e) {
				System.out.println(e);
			}catch (fufen e) {
				System.out.println(e);
			}
		}
			
	}
	
	public void shuchu() {
		int i;
		for(i=0;i<number;i++){
			System.out.println(score[i]);
		}
	}
	
	public static void main(String args[]) {
		demo1 demo=new demo1();
		demo.luru();
		demo.shuchu();
	}
}
