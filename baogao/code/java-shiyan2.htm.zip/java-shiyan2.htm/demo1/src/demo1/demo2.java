package demo1;

import java.util.Scanner;


public class demo2
{
	public static void main(String[] args){
	
		lib book1 = new lib("JAVA程序设计","丁永卫","航空工业出版社");
		System.out.println("书籍1");
		System.out.println("书名:"+book1.Aname+"\n"+"作者:"+book1.Bname+"\n"+"出版社:"+book1.Baddress);
		while(true)
		{	
		Scanner in = new Scanner(System.in);
		System.out.println("是否借阅?->1/0        查询状态->2");
		int sr;
		sr = in.nextInt();
		if(sr==1)
		{
			if(book1.getzt(book1.zt)==true)
			{
			System.out.println("书已外借");
			}else{
			book1.setzt(true);
			System.out.println("成功借阅");
			}
		}
		if(sr==0)
		{
			book1.setzt(false);
			System.out.println("取消借阅");
		}
		if(sr==2)
		{
			if(book1.getzt(book1.zt)==true)
			System.out.println("书已外借");
			else
			System.out.println("书仍在馆");
		}
	}
}
}
	class lib{
	// 创建一个图书类，类中包含的属性有：书名、作者、出版社；包含的方法有：设置书籍状态，查看书籍状态。书籍状态有在馆和外借两种。 
	public String Aname; 
	public String Bname; 
	public String Baddress; 
	
	public lib(String a,String b,String c) 
	{
		Aname=a;
		Bname=b;
		Baddress=c;
	}
	//书籍状态 
	boolean zt; 
	//包含方法 set get 
	public void setzt(boolean zt){ 
	this.zt=zt; 
	}

	public boolean getzt(boolean zt){ 
	return zt; 
	}
}