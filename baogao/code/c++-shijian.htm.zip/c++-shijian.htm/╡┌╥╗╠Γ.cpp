#include<iostream>
#include<stdio.h>
using namespace std;
class time{
public:
	int year;
	int month;
	int day;
	int hour;
	int min;
	int secend;
	void newtime(int year, int month, int day, int hour,int min,int secend)
	{
		this->year = year;
		this->month = month;
		this->day = day;
		this->hour = hour;
		this->min = min;
		this->secend = secend;
	}
	void displaytime()
	{
		cout << this->year << "-" << this->month << "-" << this->day << "\t" << this->hour << ":" << this->min << ":" << this->secend;
	}
};
int main()
{
	time t;
	t.newtime(2019, 6, 5, 9, 31, 00);
	t.displaytime();

	getchar();
	getchar();
	return 0;
}