#include<stdio.h>
#include<windows.h>
int main()
{
	int i;
	printf("choose:\n");
	printf("1.edit\n");
	printf("2.masm and run\n");
	printf("3.run\n");
	printf("0.exit\n");
	
	while(1)
	{
		scanf("%d",&i);
		switch(i)
		{
			case 1:
				system("notepad demo.asm");
				break;
			case 2:
				system("Zmasm.bat");
				break;
			case 3:
				system("Zrun.bat");
				break;
			case 0:
				return 0;
		}
		
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nchoose:\n");
	printf("1.edit\n");
	printf("2.masm and run\n");
	printf("3.run\n");
	printf("0.exit\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	}
	
	return 0;
}
